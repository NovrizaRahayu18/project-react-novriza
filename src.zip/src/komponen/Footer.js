import { Fragment } from 'react'
import './Footer.css'

function Footer() {
    return(
        <Fragment>
        <div className="footer">
            <p className="isi-footer">Copyright &copy; 2024 Crew Sun</p>
        </div>
        </Fragment>
    )
}

export default Footer